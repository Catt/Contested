contested_0.0.1
------------------
Released:  [2011-11-20-18.00]





Debriefing:
	Here's how the naming works... the first part, "contested" is the project name for the game.  The first 0 represents the version number; the second, the release number.  Both represent builds released to the public, but new versions are more profound. I'm not sure what the specific cut-off will be.  The 1 represents the pre-release build count.

	The controls right now are just WSAD for motion.  Note that when moving to the right, your avatar moves much more quickly.  This is because I wanted to test out the feel of both the dash speed and the walking speed, but I have not yet implemented a state system.

	Please critique me on any aspect of the game. I welcome it all :D


Requests:
	I need artists!  I don't know if you noticed, but the current art for the game is just a tad on the side of low quality ;)

Cheers!
-Maythe
